<?php

namespace App\Http\Controllers;

use App\CourseBackup;
use Illuminate\Http\Request;

class CourseBackupController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\CourseBackup  $courseBackup
     * @return \Illuminate\Http\Response
     */
    public function show(CourseBackup $courseBackup)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\CourseBackup  $courseBackup
     * @return \Illuminate\Http\Response
     */
    public function edit(CourseBackup $courseBackup)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\CourseBackup  $courseBackup
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CourseBackup $courseBackup)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\CourseBackup  $courseBackup
     * @return \Illuminate\Http\Response
     */
    public function destroy(CourseBackup $courseBackup)
    {
        //
    }
}
